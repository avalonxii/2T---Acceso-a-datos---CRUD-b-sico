
<?php



class conexion{
    public function conectar(){
        $info = mysqli_connect("localhost","root","","test");
        var_dump($info);
    }

    public function gestionarPublicacion(){
        $conn = mysqli_connect("localhost","root","","test");
        
        $consulta= "INSERT INTO publicaciones (titulo ,descripcion ,autor ,fecha) VALUES (?,?,?,?)";
        $sentecncia=$conn->prepare($consulta);
        $sentecncia->bind_param("ssss",$val1,$val2,$val3,$val4);
        $val1=$_POST["titulo"];
        $val2=$_POST["description"];
        $val3=$_POST["author"];
        $val4=$_POST["fecha"];
        $sentecncia->execute();
        var_dump($sentecncia);
    }

    public function consultarPublicacion(){
        $conn=mysqli_connect("localhost","root","","test");
        $consulta_select="select * from publicaciones";
        $resultado=mysqli_query($conn,$consulta_select);
        var_dump($resultado);
        while($fila=mysqli_fetch_row($resultado)){
            echo "<p> <b>Titulo</b>: ".$fila[1]."<b>Descripcion</b> :".$fila[2]." <b>Autor</b>:".$fila[3]."<b> Fecha</b> :".$fila[4]."</p>";
        }
    }
}
    